#!/usr/bin/env bash
# Matrice de connectivité du lab NetworkPolicies
# Usage : ./test-connectivity.sh
SOURCES=(
  "myapp:deploy/frontend"
  "myapp:deploy/backend1"
  "myapp:deploy/backend2"
  "app2:deploy/api"
  "default:pod/intrus"
)
DESTS=(
  "frontend.myapp"
  "backend1.myapp"
  "backend2.myapp"
  "api.app2"
)

printf "%-22s" "SOURCE \\ DEST"
for d in "${DESTS[@]}"; do printf "%-16s" "$d"; done
echo
for s in "${SOURCES[@]}"; do
  ns=${s%%:*}; res=${s#*:}
  kubectl -n "$ns" get "$res" >/dev/null 2>&1 || continue
  printf "%-22s" "$ns/${res#*/}"
  for d in "${DESTS[@]}"; do
    if kubectl -n "$ns" exec "$res" -- curl -s -m 2 -o /dev/null "http://$d" 2>/dev/null; then
      printf "%-16s" "OK"
    else
      printf "%-16s" "BLOQUE"
    fi
  done
  echo
done
echo
if curl -s -m 2 -o /dev/null http://localhost:30080; then
  echo "Externe (localhost:30080) -> frontend : OK"
else
  echo "Externe (localhost:30080) -> frontend : BLOQUE"
fi
