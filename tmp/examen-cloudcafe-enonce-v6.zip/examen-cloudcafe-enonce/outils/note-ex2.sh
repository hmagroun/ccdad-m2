#!/usr/bin/env bash
# Auto-évaluation de l'exercice 2 (note sur 10)
exec "$(dirname "$0")/note.sh" 2
