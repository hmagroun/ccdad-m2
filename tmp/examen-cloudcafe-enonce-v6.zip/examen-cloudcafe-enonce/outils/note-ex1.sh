#!/usr/bin/env bash
# Auto-évaluation de l'exercice 1 (note sur 10)
exec "$(dirname "$0")/note.sh" 1
