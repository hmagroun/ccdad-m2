#!/usr/bin/env bash
# Auto-évaluation de l'exercice 3 (note sur 10)
exec "$(dirname "$0")/note.sh" 3
