#!/usr/bin/env bash
# Supprime les ressources d'un exercice (à lancer APRÈS ./note.sh <N> : la note est déjà enregistrée)
# Usage : ./nettoyer.sh <exercice...>
[ $# -eq 0 ] && { echo "Usage : $0 <numéro d'exercice 1-7> [...]"; exit 1; }
for e in "$@"; do
  read -r -p "Supprimer toutes les ressources de l'exercice $e ? [o/N] " r
  [ "$r" = o ] || [ "$r" = O ] || continue
  echo "  (Ne relancez plus note.sh $e : c'est le DERNIER passage qui compte, et la note serait plus basse.)"
  case $e in
    1) kubectl delete ns ex1-vitrine --ignore-not-found ;;
    2) kubectl delete ns ex2-config --ignore-not-found ;;
    3) kubectl delete ns ex3-api --ignore-not-found ;;
    4) kubectl delete ns ex4-stock --ignore-not-found
       kubectl delete pv pv-stock --ignore-not-found ;;
    5) # si l'on est encore sur admin-ex5, revenir d'abord sur un autre contexte (sinon kubectl serait inutilisable)
       if [ "$(kubectl config current-context 2>/dev/null)" = admin-ex5 ]; then
         o=$(kubectl config get-contexts -o name | grep -vx admin-ex5 | head -1)
         [ -n "$o" ] && kubectl config use-context "$o"
       fi
       kubectl delete ns ex5-pki --ignore-not-found
       kubectl delete csr sami --ignore-not-found
       kubectl config delete-context admin-ex5 2>/dev/null ;;
    6) kubectl delete ns ex6-reseau ex6-externe --ignore-not-found ;;
    7) kubectl delete ns ex7-rbac --ignore-not-found
       kubectl delete clusterrolebinding ops-noeuds --ignore-not-found
       kubectl delete clusterrole lecteur-noeuds --ignore-not-found ;;
    *) echo "Exercice inconnu : $e" ;;
  esac
done
# rappel si le namespace par défaut du contexte courant vient d'être supprimé
NS=$(kubectl config view --minify -o jsonpath='{..namespace}' 2>/dev/null)
if [ -n "$NS" ] && [ "$NS" != default ] && ! kubectl get ns "$NS" >/dev/null 2>&1; then
  echo "Pensez à revenir au namespace default : kubectl config set-context --current --namespace default"
fi
