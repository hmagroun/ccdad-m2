#!/usr/bin/env bash
# Auto-évaluation - Examen TP Kubernetes « CloudCafé »
# Usage : ./note.sh <exercice...>      ex. ./note.sh 3      ./note.sh 1 2 3 4 5 6 7
# Chaque exercice est noté sur 10. Le script indique ce qui est réussi ([OK]) ou non ([KO]),
# sans explication.
# Chaque passage est enregistré dans ~/examen/resultats/exN.txt

EXAM=${EXAM:-$HOME/examen}
RES_DIR=${RES_DIR:-$EXAM/resultats}
mkdir -p "$RES_DIR"
G='\e[32m'; R='\e[31m'; B='\e[1m'; N='\e[0m'
SCORE=0; LOG=""

chk() {  # chk <points> <question> <libellé> <test>
  local pts=$1 q=$2 lib=$3; shift 3
  local ligne pad=$(( 62 - ${#lib} ))   # ${#lib} compte les caractères (accents), pas les octets
  (( pad < 0 )) && pad=0
  lib="$lib$(printf '%*s' "$pad" '')"
  if ( eval "$@" ) >/dev/null 2>&1; then
    SCORE=$(LC_ALL=C awk "BEGIN{print $SCORE+$pts}")
    ligne=$(printf "  [OK] %-4s %s %s/%s" "$q" "$lib" "$pts" "$pts")
    echo -e "${G}${ligne}${N}"
  else
    ligne=$(printf "  [KO] %-4s %s 0/%s" "$q" "$lib" "$pts")
    echo -e "${R}${ligne}${N}"
  fi
  LOG+="$ligne"$'\n'
}

# ---- fonctions de test ----
jp()    { kubectl get "$@" 2>/dev/null; }
yamls() { # yamls <exN> <kind...> : les YAML du dossier de l'exercice contiennent ces kinds
  local d=$EXAM/$1; shift
  for k in "$@"; do cat "$d"/*.yaml "$d"/*.yml 2>/dev/null | grep -Eq "kind: *$k\b" || return 1; done; }
code()  { kubectl exec -n "$1" "$2" -- curl -s -m 3 -o /dev/null -w '%{http_code}' "$3" 2>/dev/null; }
can()   { kubectl auth can-i "$@" 2>/dev/null; }
ctx()   { kubectl config view -o jsonpath="{.contexts[?(@.name==\"$1\")].context.$2}"; }
nodeip(){ jp nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}'; }
C0='{.spec.template.spec.containers[0]'

# ---------------------------------------------------------------------------
ex1() {
  local n=ex1-vitrine
  chk 1   Q2 "pod sonde"                                            '[ "$(jp pod sonde -n $n -o jsonpath="{.spec.containers[0].image}/{.metadata.labels.role}/{.status.phase}")" = "nginx:1.31.8/sonde/Running" ]'
  chk 0.5 Q3 "deployment vitrine : image"                           '[ "$(jp deploy vitrine -n $n -o jsonpath="$C0.image}")" = nginx:1.31.8 ]'
  chk 0.5 Q3 "deployment vitrine : label"                           '[ "$(jp deploy vitrine -n $n -o jsonpath="{.spec.template.metadata.labels.app}")" = vitrine ]'
  chk 0.5 Q3 "deployment vitrine : port du conteneur"               '[ "$(jp deploy vitrine -n $n -o jsonpath="$C0.ports[0].containerPort}")" = 80 ]'
  chk 1.5 Q4 "service vitrine"                                      '[ "$(jp svc vitrine -n $n -o jsonpath="{.spec.type}/{.spec.ports[0].port}/{.spec.ports[0].targetPort}/{.spec.selector.app}")" = "ClusterIP/8080/80/vitrine" ]'
  chk 1.5 Q5 "service vitrine-ext"                                  '[ "$(jp svc vitrine-ext -n $n -o jsonpath="{.spec.type}/{.spec.ports[0].port}/{.spec.ports[0].nodePort}/{.spec.selector.app}")" = "NodePort/80/30081/vitrine" ]'
  chk 1   Q6 "accès depuis sonde"                                   '[ "$(code $n sonde http://vitrine:8080)" = 200 ]'
  chk 1   Q6 "accès depuis la VM"                                   '[ "$(curl -s -m 3 -o /dev/null -w "%{http_code}" http://$(nodeip):30081)" = 200 ]'
  chk 1.5 Q7 "réplicas"                                             '[ "$(jp deploy vitrine -n $n -o jsonpath="{.spec.replicas}/{.status.readyReplicas}")" = 5/5 ] && [ "$(jp endpointslices -n $n -l kubernetes.io/service-name=vitrine -o jsonpath="{.items[*].endpoints[*].addresses[*]}" | wc -w)" -eq 5 ]'
  chk 1   YAML "fichiers YAML dans ~/examen/ex1"                    'yamls ex1 Pod Deployment Service'
}

ex2() {
  local n=ex2-config
  chk 1   Q2 "configmap cafe-env"                                   '[ -n "$(jp cm cafe-env -n $n -o jsonpath="{.data.COULEUR}")" ] && [ "$(jp cm cafe-env -n $n -o jsonpath="{.data.MODE}")" = production ]'
  chk 1   Q2 "configmap cafe-page"                                  'jp cm cafe-page -n $n -o jsonpath="{.data.index\.html}" | grep -q CloudCafe'
  chk 0.5 Q2 "secret cafe-db : DB_USER"                             '[ "$(jp secret cafe-db -n $n -o jsonpath="{.data.DB_USER}" | base64 -d)" = cafe ]'
  chk 0.5 Q2 "secret cafe-db : DB_PASSWORD"                         '[ "$(jp secret cafe-db -n $n -o jsonpath="{.data.DB_PASSWORD}" | base64 -d)" = "Esp3ss0!" ]'
  chk 0.5 Q2 "export YAML dans ~/examen/ex2"                        'yamls ex2 ConfigMap Secret'
  chk 0.5 Q3 "pod boutique"                                         '[ "$(jp pod boutique -n $n -o jsonpath="{.spec.containers[0].image}/{.status.phase}")" = "nginx:1.31.8/Running" ]'
  chk 1   Q3 "pod boutique : variables depuis cafe-env"             '[ "$(jp pod boutique -n $n -o jsonpath="{.spec.containers[0].envFrom[*].configMapRef.name}")" = cafe-env ]'
  chk 1   Q3 "pod boutique : DB_PASSWORD depuis le secret"          '[ "$(jp pod boutique -n $n -o jsonpath="{.spec.containers[0].env[?(@.name==\"DB_PASSWORD\")].valueFrom.secretKeyRef.name}")" = cafe-db ]'
  chk 1   Q3 "pod boutique : page servie"                           'kubectl exec -n $n boutique -- curl -s localhost | grep -q CloudCafe'
  chk 1   Q3 "pod boutique : secret monté en lecture seule"         'kubectl exec -n $n boutique -- test -f /etc/cafe/secret/DB_PASSWORD && jp pod boutique -n $n -o jsonpath="{.spec.containers[0].volumeMounts[?(@.mountPath==\"/etc/cafe/secret\")].readOnly}" | grep -q true'
  chk 0.5 Q4 "variables présentes dans le conteneur"                'kubectl exec -n $n boutique -- env | grep -q "^MODE=production" && kubectl exec -n $n boutique -- env | grep -q "^DB_PASSWORD=Esp3ss0!"'
  chk 0.5 Q6 "configmap cafe-env modifiée"                          '[ "$(jp cm cafe-env -n $n -o jsonpath="{.data.COULEUR}")" = vert ]'
  chk 1   Q6 "configmap cafe-page modifiée et servie"               'P=$(jp cm cafe-page -n $n -o jsonpath="{.data.index\.html}"); [ -n "$P" ] && ! echo "$P" | grep -q "CloudCafe - boutique" && [ "$(kubectl exec -n $n boutique -- curl -s localhost | tr -d "[:space:]")" = "$(echo "$P" | tr -d "[:space:]")" ]'
}

ex3() {
  local n=ex3-api
  chk 1.5 Q1 "readinessProbe"                                       '[ "$(jp deploy api -n $n -o jsonpath="$C0.readinessProbe.httpGet.port}:$C0.readinessProbe.initialDelaySeconds}:$C0.readinessProbe.periodSeconds}")" = "80:2:5" ]'
  chk 1.5 Q1 "livenessProbe"                                        '[ "$(jp deploy api -n $n -o jsonpath="$C0.livenessProbe.tcpSocket.port}:$C0.livenessProbe.initialDelaySeconds}:$C0.livenessProbe.periodSeconds}")" = "80:5:10" ]'
  chk 1   Q1 "stratégie de mise à jour"                             '[ "$(jp deploy api -n $n -o jsonpath="{.spec.strategy.type}/{.spec.strategy.rollingUpdate.maxSurge}/{.spec.strategy.rollingUpdate.maxUnavailable}")" = "RollingUpdate/1/0" ]'
  chk 0.5 Q1 "api.yaml dans ~/examen/ex3"                           'grep -q readinessProbe $EXAM/ex3/api.yaml && grep -q maxUnavailable $EXAM/ex3/api.yaml'
  chk 0.5 Q2 "nouvelle image déployée"                              'jp rs -n $n -l app=api -o jsonpath="{.items[*].spec.template.spec.containers[0].image}" | grep -q nginx:1.31.8-alpine'
  chk 0.5 Q2 "annotation change-cause"                              '[ -n "$(jp rs -n $n -l app=api -o jsonpath="{.items[*].metadata.annotations.kubernetes\.io/change-cause}")" ]'
  chk 1   Q3 "modification de la readinessProbe appliquée"          'jp rs -n $n -l app=api -o jsonpath="{.items[*].spec.template.spec.containers[0].readinessProbe.httpGet.path}" | grep -q /pret'
  chk 1.5 Q4 "état final du deployment api"                         '[ "$(jp deploy api -n $n -o jsonpath="$C0.image}|$C0.readinessProbe.httpGet.path}|{.status.updatedReplicas}|{.status.readyReplicas}")" = "nginx:1.31.8-alpine|/|4|4" ]'
  chk 1   Q5 "pod fragile : livenessProbe"                          '[ "$(jp pod fragile -n $n -o jsonpath="{.spec.containers[0].livenessProbe.httpGet.path}:{.spec.containers[0].livenessProbe.httpGet.port}:{.spec.containers[0].livenessProbe.periodSeconds}:{.spec.containers[0].livenessProbe.failureThreshold}")" = "/vivant:80:5:2" ]'
  chk 1   Q5 "pod fragile : redémarrages"                           '[ "$(jp pod fragile -n $n -o jsonpath="{.status.containerStatuses[0].restartCount}")" -ge 1 ]'
}

ex4() {
  local n=ex4-stock
  chk 2   Q1 "PV pv-stock"                                          '[ "$(jp pv pv-stock -o jsonpath="{.spec.capacity.storage}/{.spec.accessModes[0]}/{.spec.persistentVolumeReclaimPolicy}/{.spec.storageClassName}/{.spec.hostPath.path}")" = "1Gi/ReadWriteOnce/Retain/manuel//tmp/pv-stock" ]'
  chk 0.5 Q3 "PVC pvc-stock supprimé"                               'jp ns $n && ! jp pvc pvc-stock -n $n && [ "$(jp pv pv-stock -o jsonpath="{.spec.claimRef.namespace}/{.spec.claimRef.name}")" = "$n/pvc-stock" ]'
  chk 1   Q3 "état du PV pv-stock"                                  '[ "$(jp pv pv-stock -o jsonpath="{.status.phase}")" = Released ]'
  chk 1.5 Q5 "PVC pvc-commandes"                                    '[ "$(jp pvc pvc-commandes -n $n -o jsonpath="{.spec.resources.requests.storage}/{.status.phase}")" = 200Mi/Bound ] && [ "$(jp pvc pvc-commandes -n $n -o jsonpath="{.spec.storageClassName}")" = "$(jp sc -o jsonpath="{.items[?(@.metadata.annotations.storageclass\.kubernetes\.io/is-default-class==\"true\")].metadata.name}")" ]'
  chk 1   Q6 "deployment commandes"                                 '[ "$(jp deploy commandes -n $n -o jsonpath="{.spec.replicas}/$C0.image}/{.status.readyReplicas}")" = "1/nginx:1.31.8/1" ]'
  chk 1   Q6 "deployment commandes : volume"                        '[ "$(jp deploy commandes -n $n -o jsonpath="{.spec.template.spec.volumes[*].persistentVolumeClaim.claimName}")" = pvc-commandes ] && jp deploy commandes -n $n -o jsonpath="$C0.volumeMounts[*].mountPath}" | grep -qw /usr/share/nginx/html'
  chk 2   Q8 "donnée servie par le pod"                             '[ "$(kubectl exec -n $n deploy/commandes -- curl -s localhost)" = "commande 42" ]'
  chk 1   YAML "fichiers YAML dans ~/examen/ex4"                    'yamls ex4 PersistentVolume PersistentVolumeClaim Deployment'
}

ex5() {
  local n=ex5-pki d=$EXAM/ex5 cur k; cur=$(kubectl config current-context); k=$EXAM/ex5/sami.kubeconfig
  chk 0.5 Q3 "namespace ex5-pki"                                    'jp ns $n'
  chk 1   Q3 "contexte admin-ex5 : namespace"                       '[ "$(ctx admin-ex5 namespace)" = $n ]'
  chk 0.5 Q3 "contexte admin-ex5 : cluster et utilisateur"          '[ "$(ctx admin-ex5 cluster)/$(ctx admin-ex5 user)" = "$(kubectl config view --minify -o jsonpath="{.contexts[0].context.cluster}/{.contexts[0].context.user}")" ]'
  chk 1   Q4 "pod test"                                             '[ "$(jp pod test -n $n -o jsonpath="{.spec.containers[0].image}")" = nginx:1.31.8 ]'
  chk 1   Q4 "contexte courant en fin d'exercice"                   'jp pod test -n $n && [ "$cur" != admin-ex5 ]'
  chk 1   Q5 "clé et demande de certificat de sami"                 'openssl req -in $d/sami.csr -noout -subject | grep -q "CN *= *sami" && openssl req -in $d/sami.csr -noout -subject | grep -q "O *= *caisse" && openssl rsa -in $d/sami.key -check -noout'
  chk 0.5 Q6 "CSR sami : signer"                                    '[ "$(jp csr sami -o jsonpath="{.spec.signerName}")" = kubernetes.io/kube-apiserver-client ]'
  chk 0.5 Q6 "CSR sami : durée"                                     '[ "$(jp csr sami -o jsonpath="{.spec.expirationSeconds}")" = 86400 ]'
  chk 0.5 Q6 "CSR sami : approuvée et émise"                        'jp csr sami -o jsonpath="{.status.conditions[*].type}" | grep -q Approved && [ -n "$(jp csr sami -o jsonpath="{.status.certificate}")" ]'
  chk 0.5 Q6 "certificat sami.crt"                                  'openssl x509 -in $d/sami.crt -noout -subject | grep -q "CN *= *sami"'
  chk 1   Q7 "sami.kubeconfig : contexte sami@cloudcafe"            '[ "$(kubectl config view --kubeconfig $k -o jsonpath="{.current-context}|{.contexts[?(@.name==\"sami@cloudcafe\")].context.cluster}|{.contexts[?(@.name==\"sami@cloudcafe\")].context.user}|{.contexts[?(@.name==\"sami@cloudcafe\")].context.namespace}")" = "sami@cloudcafe|cloudcafe|sami|$n" ]'
  chk 0.5 Q7 "sami.kubeconfig : certificats embarqués"              '[ -n "$(kubectl config view --raw --kubeconfig $k -o jsonpath="{.users[0].user.client-certificate-data}")" ] && [ -n "$(kubectl config view --raw --kubeconfig $k -o jsonpath="{.clusters[0].cluster.certificate-authority-data}")" ]'
  chk 0.5 Q7 "kubeconfig principal inchangé pour sami"              '[ -s $k ] && ! kubectl config view -o jsonpath="{.users[*].name} {.contexts[*].name}" | grep -qw -e sami -e sami@cloudcafe'
  chk 1   Q8 "authentification de sami"                             '[ "$(kubectl --kubeconfig $k auth whoami -o jsonpath="{.status.userInfo.username}")" = sami ] && kubectl --kubeconfig $k auth whoami -o jsonpath="{.status.userInfo.groups}" | grep -q caisse'
}

ex6() {
  local n=ex6-reseau e=ex6-externe
  chk 1.5 Q2 "policy deny-all-ingress"                              '[ "$(jp netpol deny-all-ingress -n $n -o jsonpath="{.spec.podSelector}|{.spec.policyTypes[*]}|{.spec.ingress}")" = "{}|Ingress|" ]'
  chk 0.5 Q3 "policy allow-front"                                   'jp netpol allow-front -n $n'
  chk 0.5 Q3 "policy allow-front-to-api"                            'jp netpol allow-front-to-api -n $n'
  chk 0.5 Q3 "policy allow-api-to-db"                               'jp netpol allow-api-to-db -n $n'
  chk 0.5 Q3 "front -> api"                                         'jp netpol deny-all-ingress -n $n && [ "$(code $n front http://api)" = 200 ]'
  chk 0.5 Q3 "api -> db"                                            'jp netpol deny-all-ingress -n $n && [ "$(code $n api http://db)" = 200 ]'
  chk 0.5 Q3 "intrus -> front"                                      'jp netpol deny-all-ingress -n $n && [ "$(code $e intrus http://front.$n)" = 200 ]'
  chk 0.5 Q3 "front -> db"                                          '[ "$(code $n front http://db)" = 000 ]'
  chk 0.5 Q3 "intrus -> api"                                        '[ "$(code $e intrus http://api.$n)" = 000 ]'
  chk 0.5 Q3 "intrus -> db"                                         '[ "$(code $e intrus http://db.$n)" = 000 ]'
  chk 0.5 Q4 "policy front-egress"                                  '[ "$(jp netpol front-egress -n $n -o jsonpath="{.spec.policyTypes[*]}")" = Egress ]'
  chk 1   Q4 "front : résolution DNS"                               'jp netpol front-egress -n $n && kubectl exec -n $n front -- getent hosts db'
  chk 1   Q4 "front -> API server"                                  '[ "$(kubectl exec -n $n front -- curl -sk -m 3 -o /dev/null -w "%{http_code}" https://kubernetes.default 2>/dev/null)" = 000 ]'
  chk 1.5 YAML "fichiers YAML dans ~/examen/ex6"                    'yamls ex6 NetworkPolicy'
}

ex7() {
  local n=ex7-rbac sa=system:serviceaccount:ex7-rbac:deployeur
  chk 0.5 Q1 "role lecteur-pods"                                    'jp role lecteur-pods -n $n'
  chk 0.5 Q1 "rolebinding lina-lecteur"                             '[ "$(jp rolebinding lina-lecteur -n $n -o jsonpath="{.roleRef.name}/{.subjects[0].kind}/{.subjects[0].name}")" = lecteur-pods/User/lina ]'
  chk 0.5 Q1 "lina : lister les pods"                               '[ "$(can list pods -n $n --as lina)$(can watch pods -n $n --as lina)" = yesyes ]'
  chk 0.5 Q1 "lina : lire les logs"                                 '[ "$(can get pods --subresource=log -n $n --as lina)" = yes ]'
  chk 0.5 Q1 "lina : supprimer un pod"                              'jp rolebinding lina-lecteur -n $n && [ "$(can delete pods -n $n --as lina)" = no ]'
  chk 0.5 Q1 "lina : autre namespace"                               'jp rolebinding lina-lecteur -n $n && [ "$(can list pods -n default --as lina)" = no ]'
  chk 0.5 Q2 "serviceaccount deployeur"                             'jp sa deployeur -n $n'
  chk 0.5 Q2 "role gestion-deploy"                                  'jp role gestion-deploy -n $n'
  chk 0.5 Q2 "rolebinding deployeur-gestion"                        '[ "$(jp rolebinding deployeur-gestion -n $n -o jsonpath="{.roleRef.name}/{.subjects[0].kind}/{.subjects[0].name}")" = gestion-deploy/ServiceAccount/deployeur ]'
  chk 0.5 Q2 "deployeur : créer un deployment"                      '[ "$(can create deployments.apps -n $n --as $sa)" = yes ]'
  chk 0.5 Q2 "deployeur : gérer les deployments"                    '[ "$(can get deployments.apps -n $n --as $sa)$(can list deployments.apps -n $n --as $sa)$(can update deployments.apps -n $n --as $sa)$(can patch deployments.apps -n $n --as $sa)$(can delete deployments.apps -n $n --as $sa)" = yesyesyesyesyes ]'
  chk 0.5 Q2 "deployeur : créer un secret"                          'jp rolebinding deployeur-gestion -n $n && [ "$(can create secrets -n $n --as $sa)" = no ]'
  chk 0.5 Q2 "deployeur : autre namespace"                          'jp rolebinding deployeur-gestion -n $n && [ "$(can create deployments.apps -n default --as $sa)" = no ]'
  chk 0.5 Q3 "clusterrole lecteur-noeuds"                           'jp clusterrole lecteur-noeuds'
  chk 0.5 Q3 "clusterrolebinding ops-noeuds"                        '[ "$(jp clusterrolebinding ops-noeuds -o jsonpath="{.roleRef.name}/{.subjects[0].kind}/{.subjects[0].name}")" = lecteur-noeuds/Group/equipe-ops ]'
  chk 1   Q3 "groupe equipe-ops : lister les nœuds"                 '[ "$(can list nodes --as toto --as-group equipe-ops)" = yes ]'
  chk 0.5 Q3 "hors du groupe : lister les nœuds"                    'jp clusterrolebinding ops-noeuds && [ "$(can list nodes --as toto)" = no ]'
  chk 1   YAML "fichiers YAML dans ~/examen/ex7"                    'yamls ex7 Role RoleBinding'
}



TITRES=( "" "La vitrine" "Paramétrage de la boutique" "L'API des commandes" \
         "Le stock" "Le poste de caisse" "Cloisonnement réseau" "Les droits des équipes" )

[ $# -eq 0 ] && { echo "Usage : $0 <numéro d'exercice 1-7> [...]"; exit 1; }
kubectl version >/dev/null 2>&1 || { echo "Cluster injoignable (kubectl)."; exit 1; }
for e in "$@"; do
  case $e in [1-7]) ;; *) echo "Exercice inconnu : $e"; continue;; esac
  SCORE=0; LOG=""
  echo -e "${B}Exercice $e - ${TITRES[$e]}${N}"
  "ex$e"
  echo -e "${B}  Note : $SCORE / 10${N}"
  echo
  { echo "=== $(date '+%F %T') - exercice $e - note $SCORE/10"; printf "%s" "$LOG"; } >> "$RES_DIR/ex$e.txt"
done
