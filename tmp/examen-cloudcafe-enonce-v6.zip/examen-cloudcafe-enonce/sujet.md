# Examen TP Kubernetes — Étude de cas « CloudCafé »

**Durée :** 3 h — **Notation :** chaque exercice /10 — **Documents :** cet énoncé, `kubectl explain`, `kubectl <cmd> --help`, https://kubernetes.io/docs

## Contexte

La start-up **CloudCafé** vend du café en ligne. Elle migre son application vers Kubernetes et vous êtes
recruté(e) comme administrateur·rice de la plateforme. Chaque exercice correspond à une **mission
indépendante** confiée par un service de l'entreprise : vous pouvez les traiter **dans l'ordre que vous
voulez**, aucun exercice ne réutilise le résultat d'un autre.

## Environnement

- VM Ubuntu 24.04 avec un cluster **KinD** déjà opérationnel (`kubectl get nodes` doit répondre).
- IP des nœuds (pour les NodePort) : `kubectl get nodes -o wide`, colonne `INTERNAL-IP` (par ex. `172.18.0.2`
  ou `172.18.0.3`) ; un NodePort répond sur **n'importe quel** nœud.
- Image à utiliser partout : **`nginx:1.31.8`** (contient `curl`). N'utilisez jamais `latest`.
- Chaque exercice a **son propre namespace** (`ex1-...` à `ex7-...`), créé lors de sa préparation :
  respectez les noms imposés, la correction est en partie automatisée.

## Mise en place

```bash
unzip examen-cloudcafe-enonce*.zip && mv examen-cloudcafe-enonce ~/examen && cd ~/examen
echo 'alias k=kubectl' >> ~/.bashrc && alias k=kubectl      # raccourci facultatif : k = kubectl
```

Travaillez dans `~/examen/`, **un sous-dossier par exercice** (`~/examen/ex1/`, …) : les fichiers fournis
(`ex3/api.yaml`, `ex6/app.yaml`) et les outils d'auto-évaluation (`outils/`) y sont déjà.

## Déroulement de chaque exercice

Chaque exercice se fait en **trois temps**, toujours depuis `~/examen` :

1. **→ Préparation de l'environnement** : copiez-collez les commandes du bloc de préparation (namespace de
   l'exercice, qui devient le namespace par défaut de votre contexte, et application de départ) et vérifiez
   ce qu'indiquent les commentaires avant de continuer.
2. **→ Votre travail** : réalisez les manipulations demandées, puis lancez le script de notation
   (`outils/note-exN.sh`). Corrigez et relancez autant de fois que vous voulez. Les encadrés *À noter*
   expliquent ce que vous observez en chemin : ils ne demandent aucune réponse.
3. **→ Nettoyage de l'environnement** : une fois satisfait de votre note, supprimez toutes les ressources de
   l'exercice (`outils/nettoyer.sh N`) et revenez au namespace `default`.

## Auto-évaluation et barème

À la fin de votre travail sur un exercice, lancez son script de notation :

```bash
~/examen/outils/note-ex3.sh        # exemple pour l'exercice 3 (équivalent : ~/examen/outils/note.sh 3)
```

- Chaque exercice est noté **sur 10** (manipulations). Le script affiche chaque point vérifié : `[OK]`
  réussi, `[KO]` non réussi, sans explication.
- Vous pouvez **corriger et relancer** autant de fois que vous voulez, ou **passer à l'exercice suivant**.
- Chaque passage est enregistré dans `~/examen/resultats/` : c'est **le dernier passage** qui compte.
- Nettoyez chaque exercice **après** sa notation (`outils/nettoyer.sh N`). **Ne relancez plus la notation
  d'un exercice nettoyé** : le dernier passage compterait, avec une note plus basse.
- **Pas de compte-rendu ni de QCM** (comme aux certifications CKA / CKAD) : seuls comptent l'état du
  cluster au moment de la notation et, quand l'énoncé le demande, vos fichiers dans `~/examen/exN/`.
- **Note finale sur 20** = somme des 7 notes / 70 × 20.

| Ex. | Mission | Thème | Note |
|----|---------|-------|------|
| 1 | La vitrine | Pod, Deployment, Service, Namespace | /10 |
| 2 | Paramétrage de la boutique | ConfigMap, Secret | /10 |
| 3 | L'API des commandes | Health checks, Rolling update | /10 |
| 4 | Le stock | PersistentVolume, PVC, StorageClass | /10 |
| 5 | Le poste de caisse | PKI, kubeconfig, contextes | /10 |
| 6 | Cloisonnement réseau | NetworkPolicy | /10 |
| 7 | Les droits des équipes | RBAC | /10 |

## Consignes de rendu

1. **Tout objet doit être créé à partir d'un fichier YAML** enregistré dans le sous-dossier de l'exercice
   (sauf ceux des blocs de préparation, et sauf mention contraire) : la présence de ces fichiers est notée. Astuce pour générer un squelette :
   `kubectl create deployment x --image=nginx:1.31.8 --dry-run=client -o yaml > x.yaml`
2. **Ne supprimez rien** en dehors des nettoyages prévus en fin d'exercice (ni le dossier `resultats/`).
3. En fin d'épreuve : `cd ~ && zip -r examen-NOM-Prenom.zip examen/`

## Aide-mémoire général

```bash
kubectl explain deployment.spec.strategy --recursive   # la doc des champs, hors ligne
kubectl get <type> -n <ns> -o wide | -o yaml           # observer
kubectl describe <type> <nom> -n <ns>                  # Events = la 1re chose à lire en cas de souci
kubectl get events -n <ns> --sort-by=.lastTimestamp
kubectl exec -n <ns> <pod> -- <commande>               # exécuter dans un conteneur
kubectl run tmp -n <ns> --rm -it --image=nginx:1.31.8 --restart=Never -- bash   # pod jetable
alias k=kubectl ; source <(kubectl completion bash) ; complete -o default -F __start_kubectl k
```

---

## Exercice 1 — La vitrine

*Le service marketing veut mettre en ligne la vitrine du site.*

Namespace : **`ex1-vitrine`**

**→ Préparation de l'environnement de l'exercice 1**

```bash
cd ~/examen                                                   # toujours partir du dossier de l'examen
kubectl create namespace ex1-vitrine                          # namespace de l'exercice
kubectl config set-context --current --namespace ex1-vitrine  # devient le namespace par défaut
kubectl config get-contexts                                   # vérifier : colonne NAMESPACE = ex1-vitrine
kubectl get all                                               # vide : tout est à créer
```

**→ Votre travail**

```bash
# ... vos manipulations : questions ci-dessous ...
~/examen/outils/note-ex1.sh  # note sur 10 ([OK] / [KO])
```

1. Vérifiez (`kubectl config get-contexts`) que `ex1-vitrine` est bien le namespace par défaut de votre
   contexte.
2. Créez un pod **`sonde`** (image `nginx:1.31.8`, label `role=sonde`) : il servira à tester le réseau.
3. Créez un Deployment **`vitrine`** : 3 réplicas, image `nginx:1.31.8`, label `app=vitrine`, port de
   conteneur 80.
4. Créez un Service **ClusterIP `vitrine`** qui écoute sur le port **8080** et redirige vers le port 80
   des pods `app=vitrine`.
5. Créez un Service **NodePort `vitrine-ext`** (port 80 → 80) avec le `nodePort` **30081**.
6. Tests :
   - depuis le pod `sonde` : `curl http://vitrine:8080` doit renvoyer la page nginx ;
   - depuis la VM : `curl http://<IP-d-un-nœud>:30081`.
7. Passez le Deployment à **5 réplicas**. Combien d'adresses IP sont maintenant derrière le Service ?
8. Supprimez un pod du Deployment, puis le pod `sonde`.
   *À noter :* seul le pod de `vitrine` est recréé, par le **ReplicaSet** du Deployment (qui maintient 5 réplicas) ; `sonde` est un pod nu, qu'aucun contrôleur ne surveille.
   Recréez ensuite `sonde`.

**Aide-mémoire**

```yaml
apiVersion: v1
kind: Service
metadata: { name: ..., namespace: ... }
spec:
  type: NodePort            # ou ClusterIP (défaut)
  selector: { app: ... }    # doit correspondre aux labels des pods
  ports:
  - port: 80                # port du Service
    targetPort: 80          # port du conteneur
    nodePort: 30081         # NodePort uniquement (30000-32767)
```

- `kubectl create namespace`, `kubectl create deployment --replicas`, `kubectl scale`
- Voir les IP derrière un service : `kubectl get endpointslices -n <ns> -l kubernetes.io/service-name=<svc>`
- Doc : *Concepts > Workloads > Deployments* ; *Concepts > Services, Load Balancing and Networking > Service*

**→ Nettoyage de l'environnement de l'exercice 1**

```bash
cd ~/examen                                               # revenir au dossier de l'examen
outils/nettoyer.sh 1                                      # répondre « o » ; ne plus relancer note-ex1.sh ensuite
kubectl config set-context --current --namespace default  # retour au namespace default
kubectl config get-contexts                               # vérifier : NAMESPACE = default
```

---

## Exercice 2 — Paramétrage de la boutique

*L'équipe de développement veut séparer le code de la configuration.*

Namespace : **`ex2-config`**

**→ Préparation de l'environnement de l'exercice 2**

```bash
cd ~/examen                                                  # toujours partir du dossier de l'examen
kubectl create namespace ex2-config                          # namespace de l'exercice
kubectl config set-context --current --namespace ex2-config  # devient le namespace par défaut
kubectl config get-contexts                                  # vérifier : colonne NAMESPACE = ex2-config
kubectl get all                                              # vide : tout est à créer
```

**→ Votre travail**

```bash
# ... vos manipulations : questions ci-dessous ...
~/examen/outils/note-ex2.sh  # note sur 10 ([OK] / [KO])
```

1. Créez un fichier `index.html` contenant `<h1>CloudCafe - boutique</h1>`.
2. Créez :
   - une ConfigMap **`cafe-env`** avec les clés `COULEUR=bleu` et `MODE=production` ;
   - une ConfigMap **`cafe-page`** contenant le fichier `index.html` (clé `index.html`) ;
   - un Secret générique **`cafe-db`** avec `DB_USER=cafe` et `DB_PASSWORD=Esp3ss0!`.

   *Ces trois objets peuvent être créés en ligne de commande (`kubectl create configmap/secret`),
   mais exportez-les ensuite en YAML dans `~/examen/ex2/`.*
3. Créez un pod **`boutique`** (`nginx:1.31.8`) qui :
   - reçoit **toutes** les clés de `cafe-env` comme variables d'environnement ;
   - reçoit la variable `DB_PASSWORD` depuis le Secret `cafe-db` ;
   - monte la ConfigMap `cafe-page` dans `/usr/share/nginx/html` ;
   - monte le Secret `cafe-db` en lecture seule dans `/etc/cafe/secret`.
4. Vérifiez : variables (`env`), page servie (`curl -s localhost`), fichiers dans `/etc/cafe/secret`.
5. Affichez le mot de passe **décodé** à partir de l'objet Secret (sans passer par le pod).
   *À noter :* un Secret n'est **pas chiffré** : il est seulement encodé en base64, un codage réversible. Sa protection repose sur le RBAC (qui a le droit `get secrets`) et, au repos, sur le chiffrement d'etcd s'il est activé.
6. Modifiez la ConfigMap `cafe-page` (nouveau titre) et `cafe-env` (`COULEUR=vert`). Attendez 1 à 2 minutes.
   Observez la page servie et la variable `COULEUR` dans le pod.
   *À noter :* la page servie (volume de ConfigMap) est mise à jour par le kubelet au bout d'une à deux minutes ; la variable `COULEUR`, elle, ne change pas : les **variables d'environnement sont fixées au démarrage** du conteneur.

**Aide-mémoire**

```bash
kubectl create configmap <nom> --from-literal=CLE=valeur --from-file=index.html -n <ns>
kubectl create secret generic <nom> --from-literal=CLE='valeur' -n <ns>
kubectl get secret <nom> -n <ns> -o jsonpath='{.data.CLE}' | base64 -d
kubectl get configmap <nom> -n <ns> -o yaml > fichier.yaml
```

```yaml
spec:
  containers:
  - name: ...
    envFrom:
    - configMapRef: { name: ... }          # toutes les clés -> variables
    env:
    - name: VAR
      valueFrom:
        secretKeyRef: { name: ..., key: ... }   # une clé précise
    volumeMounts:
    - { name: vol-x, mountPath: /chemin, readOnly: true }
  volumes:
  - name: vol-x
    configMap: { name: ... }               # ou  secret: { secretName: ... }
```

- Doc : *Tasks > Configure Pods and Containers > Configure a Pod to Use a ConfigMap* ;
  *Concepts > Configuration > Secrets*

**→ Nettoyage de l'environnement de l'exercice 2**

```bash
cd ~/examen                                               # revenir au dossier de l'examen
outils/nettoyer.sh 2                                      # répondre « o » ; ne plus relancer note-ex2.sh ensuite
kubectl config set-context --current --namespace default  # retour au namespace default
kubectl config get-contexts                               # vérifier : NAMESPACE = default
```

---

## Exercice 3 — L'API des commandes

*L'API des commandes ne doit jamais être indisponible, même pendant une mise à jour.*

Namespace : **`ex3-api`** — fichier de départ fourni : **`ex3/api.yaml`** (Deployment `api`, 4 réplicas,
sans sonde).

**→ Préparation de l'environnement de l'exercice 3**

```bash
cd ~/examen                                               # toujours partir du dossier de l'examen
kubectl apply -f ex3/api.yaml                             # départ : namespace ex3-api, Deployment api SANS sonde
kubectl config set-context --current --namespace ex3-api  # devient le namespace par défaut
kubectl config get-contexts                               # vérifier : colonne NAMESPACE = ex3-api
kubectl rollout status deployment api                     # attendre : successfully rolled out
kubectl get deployments                                   # api : 4/4
```

**→ Votre travail**

```bash
# ... vos manipulations : questions ci-dessous ...
~/examen/outils/note-ex3.sh  # note sur 10 ([OK] / [KO])
```

1. Complétez `api.yaml` :
   - **readinessProbe** HTTP `GET /` sur le port 80 (délai initial 2 s, période 5 s) ;
   - **livenessProbe** TCP sur le port 80 (délai initial 5 s, période 10 s) ;
   - stratégie **RollingUpdate** avec `maxSurge: 1` et `maxUnavailable: 0`.

   Appliquez et vérifiez que les 4 pods sont `READY 1/1`.
2. Mettez à jour l'image en **`nginx:1.31.8-alpine`** avec `kubectl set image`, en annotant la raison du
   changement (`kubernetes.io/change-cause`). Suivez le déploiement jusqu'à la fin et affichez l'historique.
3. Un collègue modifie la readinessProbe : le chemin devient **`/pret`** (qui n'existe pas). Appliquez
   cette modification.
   Observez `kubectl rollout status` et `kubectl get pods`.
   *À noter :* le nouveau pod ne devient jamais prêt (404 sur `/pret`) et le rollout est bloqué. Avec `maxUnavailable: 0`, aucun ancien pod n'est supprimé : les **4 anciens pods restent disponibles**, le service ne perd aucune capacité.
4. Revenez à la révision précédente avec `kubectl rollout undo` et vérifiez que tout est `Ready`.
5. Créez un pod **`fragile`** (`nginx:1.31.8`) dont la **livenessProbe** fait `GET /vivant` sur le port 80
   (période 5 s, `failureThreshold: 2`).
   Observez la colonne `RESTARTS` et les Events.
   *À noter :* readinessProbe en échec : le pod est **retiré des endpoints** du Service, sans redémarrage. livenessProbe en échec : le conteneur est **redémarré** (la colonne `RESTARTS` augmente, puis `CrashLoopBackOff`).

**Aide-mémoire**

```yaml
spec:
  strategy:
    type: RollingUpdate
    rollingUpdate: { maxSurge: 1, maxUnavailable: 0 }
  template:
    spec:
      containers:
      - name: ...
        readinessProbe:
          httpGet: { path: /, port: 80 }
          initialDelaySeconds: 2
          periodSeconds: 5
        livenessProbe:
          tcpSocket: { port: 80 }
          initialDelaySeconds: 5
          periodSeconds: 10
```

```bash
kubectl set image deployment/<deploy> <conteneur>=<image> -n <ns>
kubectl annotate deployment/<deploy> kubernetes.io/change-cause="raison" -n <ns>
kubectl rollout status | history | undo  deployment/<deploy> -n <ns>
kubectl get pods -n <ns> -w            # observer en direct (Ctrl-C pour quitter)
```

- Doc : *Tasks > Configure Liveness, Readiness and Startup Probes* ; *Concepts > Workloads > Deployments
  (Updating / Rolling Back)*

**→ Nettoyage de l'environnement de l'exercice 3**

```bash
cd ~/examen                                               # revenir au dossier de l'examen
outils/nettoyer.sh 3                                      # répondre « o » ; ne plus relancer note-ex3.sh ensuite
kubectl config set-context --current --namespace default  # retour au namespace default
kubectl config get-contexts                               # vérifier : NAMESPACE = default
```

---

## Exercice 4 — Le stock

*Le service logistique a besoin de stockage qui survit aux redémarrages des pods.*

Namespace : **`ex4-stock`**

**→ Préparation de l'environnement de l'exercice 4**

```bash
cd ~/examen                                                 # toujours partir du dossier de l'examen
kubectl create namespace ex4-stock                          # namespace de l'exercice
kubectl config set-context --current --namespace ex4-stock  # devient le namespace par défaut
kubectl config get-contexts                                 # vérifier : colonne NAMESPACE = ex4-stock
kubectl get all                                             # vide : tout est à créer
kubectl get pv                                              # aucun PersistentVolume pour l'instant
```

**→ Votre travail**

```bash
# ... vos manipulations : questions ci-dessous ...
~/examen/outils/note-ex4.sh  # note sur 10 ([OK] / [KO])
```

**Partie A — provisionnement statique**

1. Créez un PersistentVolume **`pv-stock`** : 1 Gi, `ReadWriteOnce`, politique de récupération
   **`Retain`**, `storageClassName: manuel`, de type `hostPath` sur `/tmp/pv-stock`
   (`type: DirectoryOrCreate`).
2. Créez un PersistentVolumeClaim **`pvc-stock`** demandant **300 Mi** avec la classe `manuel`.
   *À noter :* PV et PVC sont `Bound`, et le PVC affiche **1Gi** : un PVC se lie à un PV **entier**. `manuel` n'est qu'une **étiquette** commune au PV et au PVC : aucune StorageClass de ce nom n'existe, donc aucun provisionnement dynamique (`storageClassName: ""` des deux côtés fonctionnerait aussi).
3. Supprimez le PVC `pvc-stock`.
   *À noter :* le PV passe à **`Released`** : avec `Retain`, les données sont conservées, et le PV n'est pas réutilisable sans l'intervention d'un administrateur (il garde la référence à l'ancien PVC).

**Partie B — provisionnement dynamique**

4. Affichez les StorageClass du cluster. Relevez le nom de la classe par défaut, son provisioner, sa
   `reclaimPolicy` et son `volumeBindingMode`.
5. Créez un PVC **`pvc-commandes`** de 200 Mi utilisant la classe par défaut.
   *À noter :* la classe par défaut utilise `volumeBindingMode: WaitForFirstConsumer` : le volume n'est créé qu'une fois **un pod qui l'utilise** planifié (question suivante), sur le nœud de ce pod.
6. Créez un Deployment **`commandes`** (1 réplica, `nginx:1.31.8`) qui monte `pvc-commandes` dans
   `/usr/share/nginx/html`. Vérifiez que le PVC passe à `Bound`.
7. Écrivez un fichier dans le volume :
   `kubectl exec -n ex4-stock deploy/commandes -- sh -c 'echo "commande 42" > /usr/share/nginx/html/index.html'`
8. Supprimez le pod (pas le Deployment). Dans le nouveau pod, vérifiez avec `curl -s localhost` que la
   donnée est toujours là.

**Aide-mémoire**

```yaml
apiVersion: v1
kind: PersistentVolume
metadata: { name: ... }                 # PV : objet NON namespacé
spec:
  capacity: { storage: 1Gi }
  accessModes: [ReadWriteOnce]
  persistentVolumeReclaimPolicy: Retain
  storageClassName: ...
  hostPath: { path: /tmp/..., type: DirectoryOrCreate }
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata: { name: ..., namespace: ... }
spec:
  accessModes: [ReadWriteOnce]
  storageClassName: ...                 # omis = classe par défaut
  resources: { requests: { storage: 300Mi } }
```

```yaml
# dans le pod template
    volumeMounts: [ { name: data, mountPath: /chemin } ]
  volumes:
  - name: data
    persistentVolumeClaim: { claimName: ... }
```

- `kubectl get pv,pvc -n <ns>` ; `kubectl get storageclass` ; `kubectl describe pvc <nom>`
- Doc : *Concepts > Storage > Persistent Volumes* ; *Concepts > Storage > Storage Classes*

**→ Nettoyage de l'environnement de l'exercice 4**

```bash
cd ~/examen                                               # revenir au dossier de l'examen
outils/nettoyer.sh 4                                      # répondre « o » ; ne plus relancer note-ex4.sh ensuite
kubectl config set-context --current --namespace default  # retour au namespace default
kubectl config get-contexts                               # vérifier : NAMESPACE = default
```

---

## Exercice 5 — Le poste de caisse

*Sami, le nouveau caissier, doit pouvoir s'authentifier sur le cluster avec un certificat.*

Namespace : **`ex5-pki`** — travaillez dans `~/examen/ex5/`.

**→ Préparation de l'environnement de l'exercice 5**

```bash
cd ~/examen                  # toujours partir du dossier de l'examen
kubectl config get-contexts  # un seul contexte, namespace default
cd ex5                       # tout l'exercice se fait dans ~/examen/ex5
```

**→ Votre travail**

```bash
# ... vos manipulations : questions ci-dessous ...
~/examen/outils/note-ex5.sh  # note sur 10 ([OK] / [KO])
```

**Partie A — explorer sa configuration**

1. Affichez le contexte courant, la liste des contextes, et l'URL de l'API server du cluster courant.
2. Extrayez le certificat client de l'utilisateur courant de votre kubeconfig et affichez son
   **sujet**, son **émetteur** et sa **date d'expiration**.
   *À noter :* l'API server accepte le certificat s'il est **signé par la CA du cluster** ; le **CN** donne le nom d'utilisateur et chaque **O** un groupe. Il n'existe pas d'objet « User » dans Kubernetes.

**Partie B — un contexte par namespace**

3. Créez le namespace `ex5-pki`, puis un contexte **`admin-ex5`** qui utilise le même cluster et le même
   utilisateur que le contexte courant, avec le namespace par défaut `ex5-pki`.
4. Basculez sur `admin-ex5`, créez un pod `test` (`nginx:1.31.8`) **sans préciser `-n`**, vérifiez qu'il
   est bien dans `ex5-pki`, puis **revenez sur le contexte d'origine**.

**Partie C — un certificat pour Sami**

5. Générez une clé privée et une demande de certificat (CSR) pour l'utilisateur **`sami`** du groupe
   **`caisse`**.
6. Soumettez-la à Kubernetes via un objet `CertificateSigningRequest` nommé **`sami`** (signer
   `kubernetes.io/kube-apiserver-client`, durée 1 jour), approuvez-la et récupérez le certificat
   dans `sami.crt`.
7. Construisez un fichier **`~/examen/ex5/sami.kubeconfig`** (certificats **embarqués**) avec un cluster
   `cloudcafe`, un utilisateur `sami` et un contexte **`sami@cloudcafe`** (namespace `ex5-pki`) — sans
   toucher à votre `~/.kube/config`.
8. Avec ce fichier : `kubectl --kubeconfig sami.kubeconfig auth whoami`, puis `get pods`.
   La 2e commande échoue.
   *À noter :* c'est un refus d'**autorisation** (403 *Forbidden*) : sami est bien **authentifié** (`whoami` fonctionne), mais aucun Role ne lui donne de droit. Un échec d'authentification donnerait 401 *Unauthorized*.

**Aide-mémoire**

```bash
kubectl config current-context | get-contexts | view [--minify] [--raw]
kubectl config view --raw --minify -o jsonpath='{.users[0].user.client-certificate-data}' | base64 -d > fichier.crt
kubectl config view --raw --minify -o jsonpath='{.clusters[0].cluster.certificate-authority-data}' | base64 -d > ca.crt
openssl x509 -in fichier.crt -noout -subject -issuer -enddate
kubectl config set-context <nom> --cluster=<cluster> --user=<user> --namespace=<ns>
kubectl config use-context <nom>
# Clé + CSR : le CN devient le nom d'utilisateur, le O devient le groupe
openssl genrsa -out user.key 2048
openssl req -new -key user.key -subj "/CN=<user>/O=<groupe>" -out user.csr
# Fichier kubeconfig séparé : ajouter --kubeconfig=<fichier> à chaque commande config
kubectl config set-cluster <nom> --server=<url> --certificate-authority=ca.crt --embed-certs --kubeconfig=<f>
kubectl config set-credentials <user> --client-certificate=user.crt --client-key=user.key --embed-certs --kubeconfig=<f>
kubectl certificate approve <csr>
kubectl get csr <csr> -o jsonpath='{.status.certificate}' | base64 -d > user.crt
```

```yaml
apiVersion: certificates.k8s.io/v1
kind: CertificateSigningRequest
metadata: { name: ... }
spec:
  request: <contenu de user.csr encodé : base64 -w0 user.csr>
  signerName: kubernetes.io/kube-apiserver-client
  expirationSeconds: 86400
  usages: [client auth]
```

- Doc : *Reference > Access Authn Authz > Certificates and Certificate Signing Requests* (section
  « Normal user ») ; *Tasks > Access Applications in a Cluster > Configure Access to Multiple Clusters*

**→ Nettoyage de l'environnement de l'exercice 5**

```bash
cd ~/examen                  # revenir au dossier de l'examen
outils/nettoyer.sh 5         # répondre « o » ; ne plus relancer note-ex5.sh ensuite
kubectl config get-contexts  # vérifier : NAMESPACE = default, contextes de l'exercice supprimés
```

---

## Exercice 6 — Cloisonnement réseau

*L'équipe sécurité impose le principe du moindre privilège sur le réseau.*

Fichier de départ fourni : **`ex6/app.yaml`**. Il crée :
- dans **`ex6-reseau`** : les pods `front` (`app=front`), `api` (`app=api`), `db` (`app=db`) et un Service
  du même nom pour chacun (port 80) ;
- dans **`ex6-externe`** : un pod `intrus` (`app=intrus`).

```
            intrus (ex6-externe)
               │
               ▼
   ───────►  front  ──────►  api  ──────►  db        (ex6-reseau)
```

**→ Préparation de l'environnement de l'exercice 6**

```bash
cd ~/examen                                                  # toujours partir du dossier de l'examen
kubectl apply -f ex6/app.yaml                                # départ : front, api, db (ex6-reseau), intrus (ex6-externe)
kubectl config set-context --current --namespace ex6-reseau  # devient le namespace par défaut
kubectl config get-contexts                                  # vérifier : colonne NAMESPACE = ex6-reseau
kubectl wait --for=condition=Ready pod --all -n ex6-reseau --timeout=120s   # attendre : 3 x condition met
kubectl wait --for=condition=Ready pod --all -n ex6-externe --timeout=120s  # attendre : 1 x condition met
kubectl get pods,services                                    # front, api, db : Running ; 3 services
kubectl get pods -n ex6-externe                              # intrus : Running
```

**→ Votre travail**

```bash
# ... vos manipulations : questions ci-dessous ...
~/examen/outils/note-ex6.sh  # note sur 10 ([OK] / [KO])
```

1. Testez et notez la matrice de connectivité **avant** toute policy
   (front→api, front→db, api→db, intrus→front, intrus→api, intrus→db).
2. Créez une policy **`deny-all-ingress`** qui bloque tout trafic entrant vers les pods de `ex6-reseau`.
   Vérifiez que plus rien ne passe.
3. Créez les policies nécessaires pour autoriser **uniquement** :
   - **`allow-front`** : tout le monde (y compris les autres namespaces) → `front` sur le port 80 ;
   - **`allow-front-to-api`** : `front` → `api` sur le port 80 ;
   - **`allow-api-to-db`** : `api` → `db` sur le port 80.

   Refaites la matrice de connectivité.
4. Créez une policy d'**egress** **`front-egress`** : le pod `front` ne peut sortir que vers `api`
   (port 80) **et** vers le DNS du cluster (pods `k8s-app=kube-dns` de `kube-system`, port 53 UDP et TCP).
   Testez **avant et après** cette policy, depuis `front` :
   - `curl ... http://api` (doit continuer à fonctionner) ;
   - `getent hosts db` (résolution DNS, doit continuer à fonctionner) ;
   - `curl -k ... https://kubernetes.default` (l'API server : un code 401/403 avant, plus rien après).

   *À noter :* dès qu'une policy `Egress` sélectionne `front`, **toute** sortie non autorisée est bloquée, y compris les requêtes DNS vers CoreDNS (`kube-system`). Sans la 2e règle, `curl http://api` échouerait faute de pouvoir résoudre le nom `api`.

**Aide-mémoire**

```bash
# test : code HTTP (200) ou échec (000) au bout de 3 s
# (un échec affiche aussi « command terminated with exit code 28 » : délai dépassé, c'est normal)
kubectl exec -n ex6-reseau front -- curl -s -m 3 -o /dev/null -w '%{http_code}\n' http://api
kubectl exec -n ex6-externe intrus -- curl -s -m 3 -o /dev/null -w '%{http_code}\n' http://front.ex6-reseau
```

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: { name: ..., namespace: ... }
spec:
  podSelector: {}                 # {} = tous les pods du namespace ; sinon matchLabels
  policyTypes: [Ingress]          # et/ou Egress
  ingress:                        # absent ou [] = tout est refusé
  - from:
    - podSelector: { matchLabels: { app: ... } }           # même namespace
    - namespaceSelector: {}                                # tous les namespaces
    - namespaceSelector: { matchLabels: { kubernetes.io/metadata.name: kube-system } }
      podSelector: { matchLabels: { k8s-app: kube-dns } }  # ET (même élément de liste)
    ports:
    - { protocol: TCP, port: 80 }
  egress:
  - to: [ ... ]                   # même syntaxe que from
    ports: [ ... ]
```

- Les policies s'**additionnent** : un flux passe si au moins une policy l'autorise.
- Doc : *Concepts > Services, Load Balancing and Networking > Network Policies*

**→ Nettoyage de l'environnement de l'exercice 6**

```bash
cd ~/examen                                               # revenir au dossier de l'examen
outils/nettoyer.sh 6                                      # répondre « o » ; ne plus relancer note-ex6.sh ensuite
kubectl config set-context --current --namespace default  # retour au namespace default
kubectl config get-contexts                               # vérifier : NAMESPACE = default
```

---

## Exercice 7 — Les droits des équipes

*Chaque équipe doit avoir exactement les droits dont elle a besoin, pas plus.*

Namespace : **`ex7-rbac`**. Les tests se font en vous faisant passer pour un autre utilisateur grâce à
l'option **`--as`** (impersonation, autorisée car vous êtes administrateur).

**→ Préparation de l'environnement de l'exercice 7**

```bash
cd ~/examen                                                # toujours partir du dossier de l'examen
kubectl create namespace ex7-rbac                          # namespace de l'exercice
kubectl config set-context --current --namespace ex7-rbac  # devient le namespace par défaut
kubectl config get-contexts                                # vérifier : colonne NAMESPACE = ex7-rbac
kubectl get all                                            # vide : tout est à créer
```

**→ Votre travail**

```bash
# ... vos manipulations : questions ci-dessous ...
~/examen/outils/note-ex7.sh  # note sur 10 ([OK] / [KO])
```

1. **Lina (support)** doit pouvoir consulter les pods et leurs logs dans `ex7-rbac`, rien d'autre.
   Créez un Role **`lecteur-pods`** (verbes `get`, `list`, `watch` sur `pods` ; `get` sur `pods/log`) et un
   RoleBinding **`lina-lecteur`** pour l'utilisateur `lina`.
   Vérifiez : Lina peut lister les pods de `ex7-rbac`, mais ne peut ni supprimer un pod, ni lister les pods
   de `default`.
2. **La CI/CD** utilise un ServiceAccount **`deployeur`** (dans `ex7-rbac`) qui doit gérer les Deployments
   (`get`, `list`, `create`, `update`, `patch`, `delete`) du namespace, et uniquement eux.
   Créez le ServiceAccount, le Role **`gestion-deploy`** et le RoleBinding **`deployeur-gestion`**.
   Vérifiez que le compte peut créer un Deployment dans `ex7-rbac`, pas un Secret, et rien dans `default`.
3. **L'équipe ops** (groupe `equipe-ops`) doit pouvoir lister les nœuds du cluster.
   Créez une ClusterRole **`lecteur-noeuds`** (`get`, `list` sur `nodes`) et une ClusterRoleBinding
   **`ops-noeuds`** pour le **groupe** `equipe-ops`. Vérifiez avec un utilisateur quelconque de ce groupe.
   *À noter :* un Role est limité à **un namespace**, alors que les nœuds sont des ressources **non namespacées** : il faut une ClusterRole et une ClusterRoleBinding.
4. Affichez la liste complète des droits de Lina dans `ex7-rbac`.

**Aide-mémoire**

```bash
kubectl create role <nom> --verb=get,list --resource=pods,pods/log -n <ns> --dry-run=client -o yaml
kubectl create rolebinding <nom> --role=<role> --user=<u> | --serviceaccount=<ns>:<sa> -n <ns>
kubectl create clusterrole <nom> --verb=... --resource=...
kubectl create clusterrolebinding <nom> --clusterrole=<cr> --group=<g>
kubectl auth can-i <verbe> <ressource> -n <ns> --as <user>
kubectl auth can-i --list -n <ns> --as <user>
kubectl get nodes --as toto --as-group equipe-ops
# un ServiceAccount s'appelle :  system:serviceaccount:<namespace>:<nom>
```

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role                        # ou ClusterRole (sans namespace)
metadata: { name: ..., namespace: ... }
rules:
- apiGroups: [""]                 # "" = core (pods, secrets...) ; "apps" = deployments
  resources: [pods, pods/log]
  verbs: [get, list, watch]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding                 # ou ClusterRoleBinding
metadata: { name: ..., namespace: ... }
roleRef: { apiGroup: rbac.authorization.k8s.io, kind: Role, name: ... }
subjects:
- { kind: User, name: ..., apiGroup: rbac.authorization.k8s.io }
# - { kind: Group, name: ..., apiGroup: rbac.authorization.k8s.io }
# - { kind: ServiceAccount, name: ..., namespace: ... }
```

- Doc : *Reference > Access Authn Authz > Using RBAC Authorization*

**→ Nettoyage de l'environnement de l'exercice 7**

```bash
cd ~/examen                                               # revenir au dossier de l'examen
outils/nettoyer.sh 7                                      # répondre « o » ; ne plus relancer note-ex7.sh ensuite
kubectl config set-context --current --namespace default  # retour au namespace default
kubectl config get-contexts                               # vérifier : NAMESPACE = default
```

---

*Bon courage !*
